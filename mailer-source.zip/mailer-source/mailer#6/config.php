<?php
/**
 * Configuration Array
 */

const CONFIG = [

    'email' => [
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'username' => 'YOUR-GMAIL@gmail.com',
        'password' => 'YOUR-GMAIL-PASSWORD',
        'SMTPSecure' => 'tls'
    ],

    

];