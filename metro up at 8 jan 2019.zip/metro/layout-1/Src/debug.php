<?php
/**
 * Created by PhpStorm.
 * User: A M Robiul Islam
 * Date: 1/7/2019
 * Time: 8:31 AM
 */
echo "<pre>";
print_r($_REQUEST);
echo "</pre>";