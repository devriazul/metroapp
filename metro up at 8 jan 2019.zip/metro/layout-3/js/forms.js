(function ($) {

	"use strict";

	var $document = $(document),
		$window = $(window),
		forms = {
			contactForm: $('#contactform'),
			appointmentForm: $('#appointment-form'),
			quoteForm: $('#quote-form')
		};

	$document.ready(function () {

		// quote form
		if (forms.quoteForm.length) {
			var $quoteForm = forms.quoteForm;
			$quoteForm.validate({
				rules: {
					name: {
						required: true,
						minlength: 2
					},
					message: {
						required: true,
						minlength: 20
					},
					email: {
						required: true,
						email: true
					}

				},
				messages: {
					name: {
						required: "Please enter your name",
						minlength: "Your name must consist of at least 2 characters"
					},
					message: {
						required: "Please enter message",
						minlength: "Your message must consist of at least 20 characters"
					},
					email: {
						required: "Please enter your email"
					}
				},
				submitHandler: function (form) {
					$(form).ajaxSubmit({
						type: "POST",
						data: $(form).serialize(),
						url: "form/process-quote.php",
						success: function () {
							$('#successQuote').fadeIn();
							$('#quote-form').each(function () {
								this.reset();
							});
						},
						error: function () {
							$('#quote-form').fadeTo("slow", 0, function () {
								$('#errorQuote').fadeIn();
							});
						}
					});
				}
			});
		}


		// appointment form
		if (forms.appointmentForm.length) {
			var $appointmentForm = forms.appointmentForm;
			$appointmentForm.validate({
				rules: {
					name: {
						required: true,
						minlength: 2
					},
					message: {
						required: true,
						minlength: 20
					},
					email: {
						required: true,
						email: true
					}

				},
				messages: {
					name: {
						required: "Please enter your name",
						minlength: "Your name must consist of at least 2 characters"
					},
					message: {
						required: "Please enter message",
						minlength: "Your message must consist of at least 20 characters"
					},
					email: {
						required: "Please enter your email"
					}
				},
				submitHandler: function (form) {
					$(form).ajaxSubmit({
						type: "POST",
						data: $(form).serialize(),
						url: "form/process-appointment.php",
						success: function () {
							$('#successAppointment').fadeIn();
							$('#appointment-form').each(function () {
								this.reset();
							});
						},
						error: function () {
							$('#appointment-form').fadeTo("slow", 0, function () {
								$('#errorAppointment').fadeIn();
							});
						}
					});
				}
			});
		}

		// contact page form
		if (forms.contactForm.length) {
			var $contactform = forms.contactForm;
			$contactform.validate({
				rules: {
					name: {
						required: true,
						minlength: 2
					},
					message: {
						required: true,
						minlength: 20
					},
					email: {
						required: true,
						email: true
					}

				},
				messages: {
					name: {
						required: "Please enter your name",
						minlength: "Your name must consist of at least 2 characters"
					},
					message: {
						required: "Please enter message",
						minlength: "Your message must consist of at least 20 characters"
					},
					email: {
						required: "Please enter your email"
					}
				},
				submitHandler: function (form) {
					$(form).ajaxSubmit({
						type: "POST",
						data: $(form).serialize(),
						url: "form/process-contact.php",
						success: function () {
							$('#success').fadeIn();
							$('#contactform').each(function () {
								this.reset();
							});
						},
						error: function () {
							$('#contactform').fadeTo("slow", 0, function () {
								$('#error').fadeIn();
							});
						}
					});
				}
			});
		}
		// datepicker
		if ($('.datetimepicker').length) {
			$('.datetimepicker').datetimepicker({
				format: 'DD/MM/YYYY',
				icons: {
					time: 'icon icon-clock',
					date: 'icon icon-calendar',
					up: 'icon icon-arrow_up',
					down: 'icon icon-arrow_down',
					previous: 'icon icon-arrow-left',
					next: 'icon icon-arrow-right',
					today: 'icon icon-today',
					clear: 'icon icon-trash',
					close: 'icon icon-cancel-music'
				}
			});
		}
		if ($('.timepicker').length) {
			$('.timepicker').datetimepicker({
				format: 'LT',
				icons: {
					time: 'icon icon-clock',
					up: 'icon icon-arrow_up',
					down: 'icon icon-arrow_down',
					previous: 'icon icon-arrow-left',
					next: 'icon icon-arrow-right'
				}
			});
		}

		// estimate form
		
		if ($('#estimatorForm').length) {
			$('#estimatorSelect2').dependsOn({
				'#estimatorSelect1': {
					not: ['select']
				}
			}, {
				hide: false
			});
			$('#estimatorSelect3').dependsOn({
				'#estimatorSelect2': {
					not: ['select']
				},
				'#estimatorSelect1': {
					not: ['select']
				}
			}, {
				hide: false
			});
			$('#estimatorInput1').dependsOn({
				'#estimatorSelect3': {
					not: ['select']
				},
				'#estimatorSelect2': {
					not: ['select']
				},
				'#estimatorSelect1': {
					not: ['select']
				}
			}, {
				hide: false
			});
			$('#estimatorSubmit').dependsOn({
				'#estimatorInput1': {
					not: ['Repair Needed']
				},
				'#estimatorSelect3': {
					not: ['select']
				},
				'#estimatorSelect2': {
					not: ['select']
				},
				'#estimatorSelect1': {
					not: ['select']
				}
			}, {
				hide: false
			});
			$('#estimatorSubmitModal').on('click', function () {
				var services = [];
				$("input[name='service']:checked").each(function () {
					services.push($(this).val());
				});
				console.log(services, services.toString())
				$('#estimatorInput1').val(services.toString());
				$('#estimatorSubmit').removeAttr("disabled").trigger('click')
				window.location.href = $('#estimatorSubmit').attr('href');
			})
		}

	});

})(jQuery);