<?php
/**
 * Created by PhpStorm.
 * User: A M Robiul Islam
 * Date: 1/5/2019
 * Time: 8:09 PM
 */

namespace Metro\Products;
use PDO;
use PDOException;

class Batteries{

    public $id, $uId,$vehicleMake,$vehicleModel,$vehicleYear,$vehicleVariant,
        $vehicleType,$ccaRating,$partNumber,$warranty,$price,$comment,$status;

    public $create_at,$updated_at,$deleted_at;

    public $data;
    public $conn;


    public function __construct() {
        if (session_status() == PHP_SESSION_NONE) {
            session_start();
        }
        try {
            $this->conn = new PDO('mysql:host=localhost;dbname=db_metro', 'root', '');
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }


    // assign data into variable
    public function assign($data) {
        if (!empty($data['uId'])) {
            $this->uId = $data['uId'];
        }

        if (!empty($data['vMake'])) {
            $this->vehicleMake = $data['vMake'];
        }

        if (!empty($data['vModel'])) {
            $this->vehicleModel = $data['vModel'];
        }
        if (!empty($data['vYear'])) {
            $this->vehicleYear = $data['vYear'];
        }
        if (!empty($data['vVariant'])) {
            $this->vehicleVariant = $data['vVariant'];
        }

        if (!empty($data['vType'])) {
            $this->vehicleType = $data['vType'];
        }

        if (!empty($data['ccaRating'])) {
            $this->ccaRating = $data['ccaRating'];
        }

        if (!empty($data['partNumber'])) {
            $this->partNumber = $data['partNumber'];
        }

        if (!empty($data['warranty'])) {
            $this->warranty = $data['warranty'];
        }

        if (!empty($data['price'])) {
            $this->price = $data['price'];
        }

        if (!empty($data['comment'])) {
            $this->comment = $data['comment'];
        }

        if (!empty($data['status'])) {
            $this->status = $data['status'];
        }

        if (!empty($data['create_at'])) {
            $this->create_at = $data['create_at'];
        }

        if (!empty($data['updated_at'])) {
            $this->updated_at = $data['updated_at'];
        }

        if (!empty($data['deleted_at'])) {
            $this->deleted_at = $data['deleted_at'];
        }

        if (!empty($data['create_at'])) {
            $originalDate = $data['create_at'];
            $newDate = date("Y-m-d", strtotime($originalDate));
            $this->start_date = $newDate;
        }

        $this->status = 1;

        return $this;
    }


    // get course list
    public function getMakeList() {
        try {
            $Query = "SELECT DISTINCT vehicleMake FROM tbl_batteries ORDER BY vehicleMake ASC";
            $q = $this->conn->query($Query);
            $rowCount = $q->rowCount();
            if ($rowCount > 0) {
                while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
                    $this->data[] = $row;
                }
                return $this->data;
            } else {
                return $rowCount;
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        return $this;
    }

    // get type info
    public function getTypeInfo() {
        try {
            $Query = "SELECT * FROM tbl_batteries ORDER BY vehicleMake ASC";
            $q = $this->conn->query($Query);
            $rowCount = $q->rowCount();
            if ($rowCount > 0) {
                while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
                    $this->data[] = $row;
                }
                return $this->data;
            } else {
                return $rowCount;
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        return $this;
    }

    public function getBatteriesTypeInfo(){

//        echo 'ase ki make?: '.$this->vehicleMake.' ? hlw<br>';
//        echo 'ase ki make?: '.$this->vehicleModel.' ? hlw<br>';
//        echo 'ase ki make?: '.$this->vehicleYear.' ? hlw<br>';
//        echo 'ase ki make?: '.$this->vehicleVariant.' ? hlw<br>';


        try {
            $Query = "SELECT * FROM tbl_batteries WHERE vehicleMake = '$this->vehicleMake' AND vehicleModel = '$this->vehicleModel' AND vehicleYear = '$this->vehicleYear' AND vehicleVariant = '$this->vehicleVariant' ";
            $q = $this->conn->query($Query);
//            $q->execute(array(
//                ':make' => 'Alfa Romeo',
//                ':model' => '90',
//                ':year' => '1985 to 1988',
//                ':variant' => 'ALL'
//            ));
            $rowCount = $q->rowCount();
            if ($rowCount > 0) {
                while ($row = $q->fetch(PDO::FETCH_ASSOC)) {
                    $this->data[] = $row;
                }
                return $this->data;
            } else {
                return $rowCount;
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
        return $this;

    }














}