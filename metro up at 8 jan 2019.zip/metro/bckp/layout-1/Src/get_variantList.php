<?php
session_start();

require_once("dbcontroller.php");
$db_handle = new DBController();

//if(!empty($_SESSION['vMake']) && !empty($_SESSION['vModel']) && !empty($_SESSION['vYear'])) {

    $query = "SELECT DISTINCT vehicleVariant FROM tbl_batteries WHERE vehicleMake = '$_SESSION[vMake]' AND vehicleModel = '$_SESSION[vModel]' AND vehicleYear = '$_POST[vYear]' ORDER BY `vehicleVariant` ASC";
	$results = $db_handle->runQuery($query);
echo $query;
?>
    <option value="">To finish, the variant</option>
<?php
	foreach($results as $vVariant) {
        $_SESSION['vYear'] = $_POST['vYear'];

?>
	<option value="<?php echo $vVariant["vehicleVariant"]; ?>"><?php echo $vVariant["vehicleVariant"]; ?></option>
<?php
//	}
}

?>


