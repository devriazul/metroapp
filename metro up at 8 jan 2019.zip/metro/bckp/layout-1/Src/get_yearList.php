<?php
session_start();
require_once("dbcontroller.php");
$db_handle = new DBController();



//if(!empty($_POST['vMake']) && !empty($_POST['vModel'])) {


    $query = "SELECT DISTINCT vehicleYear FROM tbl_batteries WHERE vehicleMake = '$_SESSION[vMake]' AND vehicleModel = '$_POST[vModel]' ORDER BY `vehicleYear` ASC";
	$results = $db_handle->runQuery($query);

	echo $query;
?>
    <option value="">Pick the Year</option>
<?php


	foreach($results as $vYear) {
        $_SESSION['vModel'] = $_POST["vModel"];

?>
	<option value="<?php echo $vYear["vehicleYear"]; ?>"><?php echo $vYear["vehicleYear"]; ?></option>
<?php
//	}
}
?>