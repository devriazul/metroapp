<?php
session_start();
require_once("dbcontroller.php");
$db_handle = new DBController();
//if(!empty($_POST["vMake"])) {
	$query ="SELECT DISTINCT vehicleModel FROM tbl_batteries WHERE vehicleMake = '" . $_POST["vMake"] . "'";
	$results = $db_handle->runQuery($query);
echo $query;
?>
    <option value="">Select the Model</option>
<?php
	foreach($results as $vModel) {
	    $_SESSION['vMake'] = $_POST["vMake"];
?>
	<option value="<?php echo $vModel["vehicleModel"]; ?>"><?php echo $vModel["vehicleModel"]; ?></option>
<?php
//	}
}
?>