<form action="index.php" method="POST" id="form1">
    <input id="getaquote" type="submit" name="btnsubmitstep0" value="Get a Quote">
</form>
