<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'PHPMailer-6.0.3/src/Exception.php';
require 'PHPMailer-6.0.3/src/PHPMailer.php';
require 'PHPMailer-6.0.3/src/SMTP.php';

$toAddress = "abishar14@gmail.com"; //To whom you are sending the mail.
$message   = <<<EOT
    <html>
       <body>
          <h>PHPMailer basic usage</h>
          <p>It is working</p>
       </body>
    </html>
EOT;
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPAuth    = true;
$mail->Host        = "smtp.gmail.com";
$mail->Port        = 587;
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);
$mail->IsHTML(true);
$mail->Username = "abishar14@gmail.com"; // your gmail address
$mail->Password = "Tumi4@mi"; // password
$mail->SetFrom("abishar14@gmail.com");
$mail->Subject = "Using PHPMailer without composer"; // Mail subject
$mail->Body    = $message;
$mail->AddAddress($toAddress);
if (!$mail->Send()) {
    echo "Failed to send mail";
    
} else {
    echo "Mail sent succesfully";
}
?>